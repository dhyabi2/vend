# vend-client

Python client for [Vend API Merchant](https://paypercall.dev) — pay-per-call APIs settled in Nano (XNO). No signup, no API key.

## Install

```bash
pip install vend-client           # dry-run (read prices)
pip install vend-client[paid]     # with Nano payment support
```

## Quick start (dry-run — see prices)

```python
from vend_client import VendClient

client = VendClient()
result = client.extract("https://example.com")
# Returns the 402 challenge with price, payTo, and endpoint info
print(result["price_xno"], "XNO")
print(result["pay_to"])
```

## Paid call (with a Nano wallet)

```python
from vend_client import VendClient
from nano_pay.wallet import Wallet

wallet = Wallet(seed_path="/path/to/seed.txt")
client = VendClient(wallet=wallet)

result = client.extract("https://example.com")
print(result["title"])
print(result["text"][:200])
```

## CLI

```bash
# Dry-run: see what a call would cost
vend-client extract --url https://example.com

# Paid call (with wallet)
vend-client --wallet /path/to/seed.txt extract --url https://example.com

# Other endpoints
vend-client check-link --url https://example.com
vend-client domain-info --domain example.com
vend-client web-search --q "latest Nano news"
vend-client geoip --ip 8.8.8.8
vend-client nano-info --account nano_1...
```

## Endpoints

| Service | Endpoint | Price (XNO) | Description |
|---------|----------|-------------|-------------|
| extract | /api/v1/extract | 0.0001 | Extract clean text/markdown from a URL |
| check-link | /api/v1/check-link | 0.0001 | HTTP status, response time, redirect chain |
| domain-info | /api/v1/domain-info | 0.0005 | DNS, WHOIS, TLS cert, HTTP headers |
| web-search | /api/v1/web-search | 0.0001 | Web search via DuckDuckGo |
| geoip | /api/v1/geoip | 0.0001 | IP geolocation |
| nano-info | /api/v1/nano-info | 0.0005 | Nano account intelligence |

## How payment works

1. Call the endpoint without payment → HTTP 402 with Nano price and pay-to account
2. Send the Nano amount to the quoted account (feeless, ~1 second)
3. Call again with the block hash in `X-PAYMENT` header → HTTP 200 with your data

## License

MIT